
package nota;

import java.util.Scanner;

public class Nota {

    public static void main(String[] args) {
       int[] vetor = new int[10];
                
                Scanner entrada = new Scanner(System.in);
                int nota=0;
                
                while(nota!= -1){
                System.out.println("Informe notas ou digite -1 para finalizar");
                nota = entrada.nextInt();
                
                if(nota == -1){
                    break;
                }
                vetor[nota/10]++;
                }
		System.out.println("Distribuição de notas:");
		
		for (int contador = 0; contador < vetor.length; contador++) {
			// gera saída do código de barras ( "00-09: ", ...., "90-99: ", "100: ")
			if (contador == 10)
				System.out.printf("%5d: ", 100);
			else
				System.out.printf("%02d-%02d: ",
						contador * 10, contador * 10 + 9);
			
			// imprime a barra de asteriscos
			for (int estrelas = 0; estrelas < vetor[contador]; estrelas++) {
				System.out.print("*");
			}
			
			System.out.println();
			
		}

	}

}
    
    


    
    

